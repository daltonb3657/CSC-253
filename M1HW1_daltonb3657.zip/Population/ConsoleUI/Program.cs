﻿/*
 * 8/29/20
 * CSC 253
 * Brandon Dalton 
 * A population growth estimation program
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PopulationLib;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;
            Console.WriteLine(StandardMessages.WelcomeMessage());

            do
            {
                Console.WriteLine(StandardMessages.Menu());
                switch(Console.ReadLine())
                {
                    case "1":
                        PopulationGrowth.PopulationgGrowthMath();
                        break;
                    case "2":
                        exit = true;
                        break;
                }
            } while (exit == false);
        }
    }
}
