﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PopulationLib;

namespace ConsoleUI
{
    public class PopulationGrowth
    {
        public static void PopulationgGrowthMath()
        {
            String input;
            bool error = false;
            double organisms, dailyIncrease, dailyIncreasePercent, population;
            int numberOfDays;            

            do
            {
                Console.Write(StandardMessages.Organisms());
                input = Console.ReadLine();
                if (double.TryParse(input, out organisms))
                {
                    //parse correctly
                    error = false;
                }
                else
                {
                    Console.WriteLine(StandardMessages.NumberError());
                    error = true;
                }
            } while (error == true);

            
            do
            {
                Console.Write(StandardMessages.DailyIncrease());
                input = Console.ReadLine();
                if (double.TryParse(input, out dailyIncrease))
                {
                    //parse correctly
                    
                    error = false;
                }
                else
                {
                    Console.WriteLine(StandardMessages.NumberError());
                    error = true;
                }
            } while (error == true);
            dailyIncreasePercent = dailyIncrease / 100;

            do
            {
                Console.Write(StandardMessages.NumberOfDays());
                input = Console.ReadLine();
                if(int.TryParse(input, out numberOfDays))
                {
                    //parse correclty
                    error = false;
                }
                else
                {
                    Console.WriteLine(StandardMessages.NumberError());
                    error = true;
                }
            } while (error == true);

            population = organisms + (organisms * dailyIncreasePercent * numberOfDays);

            Console.WriteLine($"Starting number of organisms: {organisms}" +
                $"\n Average daily increase: {dailyIncrease}%" +
                $"\n Number of days to multiply: {numberOfDays}" +
                $"\n New oganism population: {population}");
        }

        

    }
}
