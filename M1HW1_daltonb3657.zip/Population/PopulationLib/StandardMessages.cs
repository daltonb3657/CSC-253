﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PopulationLib
{
    public class StandardMessages
    {
        public static String WelcomeMessage()
        {
            return "Wleomce to the Population Growth Estimation Program.";
        }

        public static String Menu()
        {
            return "1. Run Poultation increase program." +
                "\n2. Exit";
        }

        public static String MenuError()
        {
            return "Invalid input! Please enter a number from the menu.";
        }

        public static String Organisms()
        {
            return "Enter starting number of organisms: ";
        }

        public static String DailyIncrease()
        {
            return "Enter the average daily increase(as a percentage): ";
        }
        
        public static String NumberOfDays()
        {
            return "Enter the number of days to multiply: ";
        }
        public static String NumberError()
        {
            return "Invalid input! Please enter a number.";
        }
    }
}
