﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AreaClassLib
{
    public class StandardMessages
    {
        public static String DisplayWelcomeMessage()
        {
            return "Welcome to the area calculation program.";
        }
        public static String DisplayMenu()
        {
            return "1. Area of a circle" +
                "\n2. Area of a rectangle" +
                "\n3. Area of a cylinder" +
                "\n4. Exit" +
                "\n--> ";
        }
        public static String DisplayMenuError()
        {
            return "Invalid input! Please enter a number from the menu.";
        }

        public static String GetRadius()
        {
            return "Enter the radius: ";
        }
        public static String GetLength()
        {
            return "Enter the length: ";
        }
        public static String GetWidth()
        {
            return "Enter the width: ";
        }
        public static String GetHeight()
        {
            return "Enter the height: ";
        }
        public static String DisplayNumberError()
        {
            return "Invalid input! Enter a number greater than 0";
        }

    }
}
