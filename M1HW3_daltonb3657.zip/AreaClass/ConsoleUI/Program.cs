﻿/*
 * CSC-253
 * Brandon Dalton
 * 9/6/20
 * This program uses an area class with overloaded methods to calculate the area of a circle, rectangle, and cylinder
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AreaClassLib;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;
            bool error = false;
            Console.WriteLine(StandardMessages.DisplayWelcomeMessage());

            do
            {
                Console.Write(StandardMessages.DisplayMenu());

                switch (Console.ReadLine())
                {
                    case "1":
                        double radiusCircle, areaCircle;
                        
                        do
                        {
                            Console.Write(StandardMessages.GetRadius());
                            radiusCircle = ConvertInput.ConvertToDouble(Console.ReadLine());
                            if(radiusCircle < 0)
                            {
                                error = true;
                                Console.WriteLine(StandardMessages.DisplayNumberError());
                            }
                            else
                            {
                                error = false;
                            }
                        } while (error == true);

                        areaCircle = AreaClass.Area(radiusCircle);
                        Console.WriteLine($"The area of the circle is {areaCircle}");
                        break;
                    case "2":
                        int length, width;
                        double areaRectangle;

                        do
                        {
                            Console.Write(StandardMessages.GetLength());
                            length = ConvertInput.ConvertToInt(Console.ReadLine());
                            if(length < 0)
                            {
                                error = true;
                                Console.WriteLine(StandardMessages.DisplayNumberError());
                            }
                            else
                            {
                                error = false;
                            }
                        } while (error == true);
                        do
                        {
                            Console.Write(StandardMessages.GetWidth());
                            width = ConvertInput.ConvertToInt(Console.ReadLine());
                            if (width < 0)
                            {
                                error = true;
                                Console.WriteLine(StandardMessages.DisplayNumberError());
                            }
                            else
                            {
                                error = false;
                            }
                        } while (error == true);

                        areaRectangle = AreaClass.Area(width, length);
                        Console.WriteLine($"The area of the rectangle is {areaRectangle}");
                        break;
                    case "3":
                        double radiusCylinder, areaCylinder, height;

                        do
                        {
                            Console.Write(StandardMessages.GetRadius());
                            radiusCylinder = ConvertInput.ConvertToDouble(Console.ReadLine());
                            if(radiusCylinder < 0)
                            {
                                error = true;
                                Console.WriteLine(StandardMessages.DisplayNumberError());
                            }
                            else
                            {
                                error = false;
                            }

                        } while (error == true);
                        do
                        {
                            Console.Write(StandardMessages.GetHeight());
                            height = ConvertInput.ConvertToDouble(Console.ReadLine());
                            if (height < 0)
                            {
                                error = true;
                                Console.WriteLine(StandardMessages.DisplayNumberError());
                            }
                            else
                            {
                                error = false;
                            }

                        } while (error == true);

                        areaCylinder = AreaClass.Area(radiusCylinder, height);
                        Console.WriteLine($"The area of the cylinder is {areaCylinder}");
                        break;
                    case "4":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine(StandardMessages.DisplayMenuError());
                        break;
                }


            } while (exit == false);
        }
    }
}
