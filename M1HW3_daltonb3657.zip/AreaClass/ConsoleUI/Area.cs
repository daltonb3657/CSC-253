﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    public class AreaClass
    {
        public static double Area(double radius)
        {
            return Math.PI * Math.Pow(radius, 2);
        }
        
        public static double Area(int width, int length)
        {
            return width * length;
        }

        public static double Area(double radius, double height)
        {
            return 2 * Math.PI * Math.Pow(radius, 2) + height * (2 * Math.PI * radius);
        }
    }
}
