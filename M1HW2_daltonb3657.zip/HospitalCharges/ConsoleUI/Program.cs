﻿/*
 * CSC-253
 * Brandon Dalton
 * 9/6/20
 * This program calculates hospital charges and returns a total bill
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HospitalChargesLib;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;

            Console.WriteLine(StandardMessages.DisplayWelcomeMessage());
            do
            {
                Console.Write(StandardMessages.DisplayMenu());

                switch(Console.ReadLine())
                {
                    case "1":
                        double stayCharge = CalcStayCharges(), miscCharge = CalcMiscCharges(), totalCharge=CalcTotalCharges(stayCharge,miscCharge);
                        Console.WriteLine(StandardMessages.DisplayTotalBill(stayCharge,miscCharge,totalCharge));
                        break;
                    case "2":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine(StandardMessages.DisplayMenuError());
                        break;
                }

            } while (exit == false);

        }
        public static double CalcStayCharges()
        {
            bool error = false;
            int days, dailyCharge = 350;
            
            Console.WriteLine(StandardMessages.DisplayDailyCharge());
            do
            {
                Console.Write(StandardMessages.GetNumberOfDays());
                days = ConvertInput.ConvertToInt(Console.ReadLine());
                if (days < 0)
                {
                    error = true;
                    Console.WriteLine(StandardMessages.DisplayNumberError());
                }
                else
                {
                    error = false;
                }
            } while (error == true);

            return days * dailyCharge;

            
        }
        public static double CalcMiscCharges()
        {
            bool error = false;
            double medicationCharge, surgicalCharge, labFee, RehabCharge;
            do
            {
                Console.Write(StandardMessages.GetMedicationCharge());
                medicationCharge = ConvertInput.ConvertToDouble(Console.ReadLine());
                if (medicationCharge < 0)
                {
                    error = true;
                    Console.WriteLine(StandardMessages.DisplayNumberError());
                }
                else
                {
                    error = false;
                }
            } while (error == true);
            do
            {
                Console.Write(StandardMessages.GetSurgicalCharge());
                surgicalCharge = ConvertInput.ConvertToDouble(Console.ReadLine());
                if (surgicalCharge < 0)
                {
                    error = true;
                    Console.WriteLine(StandardMessages.DisplayNumberError());
                }
                else
                {
                    error = false;
                }
            } while (error == true);
            do
            {
                Console.Write(StandardMessages.GetLabFee());
                labFee = ConvertInput.ConvertToDouble(Console.ReadLine());
                if (labFee < 0)
                {
                    error = true;
                    Console.WriteLine(StandardMessages.DisplayNumberError());
                }
                else
                {
                    error = false;
                }
            } while (error == true);
            do
            {
                Console.Write(StandardMessages.GetRehabCharge());
                RehabCharge = ConvertInput.ConvertToDouble(Console.ReadLine());
                if (RehabCharge < 0)
                {
                    error = true;
                    Console.WriteLine(StandardMessages.DisplayNumberError());
                }
                else
                {
                    error = false;
                }
            } while (error == true);            

            return medicationCharge + surgicalCharge + labFee + RehabCharge;
        }
        public static double CalcTotalCharges(double stayCharge, double miscCharge)
        {
            return stayCharge + miscCharge;
        }
    }
}
