﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalChargesLib
{
    public class StandardMessages
    {
        public static String DisplayMenu()
        {
            return "1. Run Program" +
                "\n2. Exit" +
                "\n-> ";
        }
        public static String DisplayWelcomeMessage()
        {
            return "Welcome to the hospital charge program.";
        }

        public static String DisplayDailyCharge()
        {
            return "The hospital charges $350 per day.";
        }

        public static String GetNumberOfDays()
        {
            return "Enter days spent in the hospital: ";
        }
        public static String GetMedicationCharge()
        {
            return "Enter the medication charges: ";
        }
        public static String GetSurgicalCharge()
        {
            return "Enter the surgical charges: ";
        }
        public static String GetLabFee()
        {
            return "Enter the lab fees: ";
        }
        public static String GetRehabCharge()
        {
            return "Enter physical rehabilitation charges: ";
        }
        public static String DisplayNumberError()
        {
            return "Invalid entry! Please enter a number greater than 0.";
        }
        public static String DisplayMenuError()
        {
            return "Invalid entry! Please enter a number from the list.";
        }
        public static String DisplayTotalBill(double stayCharge, double miscCharge, double totalCharge)
        {
            return $"Total Stay Charge: ${stayCharge}" +
                $"\nTotal Misc. Charge: ${miscCharge}" +
                $"\nTotal Hospital Charge: ${totalCharge}";
        }
    }
}
