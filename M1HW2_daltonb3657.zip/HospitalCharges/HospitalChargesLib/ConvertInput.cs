﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalChargesLib
{
    public class ConvertInput
    {
        public static int ConvertToInt(string input)
        {
            int output = 0;


            if (int.TryParse(input, out output))
            {
                return output;
            }
            else
            {
                output = -1;
                return output;
            }
        }

        public static double ConvertToDouble(string input)
        {
            double output = 0.0;


            if (double.TryParse(input, out output))
            {
                return output;
            }
            else
            {
                output = -1;
                return output;
            }
        }
    }
}
